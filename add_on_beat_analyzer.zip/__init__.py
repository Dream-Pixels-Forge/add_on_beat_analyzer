bl_info = {
    "name": "Beat Analyzer Pro",
    "author": "Dimona Patrick",
    "version": (1, 0, 5),
    "blender": (4, 2, 0),
    "location": "View3D > Sidebar > Beat Analyzer Pro",
    "description": "Audio beat analysis with shader and geometry nodes support",
    "warning": "Beta",
    "doc_url": "https:github.com/Dream-Pixels-Forge",
    "category": "Animation",
}

import bpy
import wave
import os
import time
import json
import numpy as np
import threading
from datetime import datetime
from bpy.props import (
    FloatProperty,
    StringProperty,
    IntProperty,
    BoolProperty,
    EnumProperty,
    FloatVectorProperty,
    PointerProperty,
)
from bpy.types import (
    Panel,
    Operator,
    PropertyGroup,
)



def toggle_audio_mute_state(context):
    bpy.ops.beatanalyzer.toggle_mute()

def set_audio_mute_state(context, mute_state):
    props = context.scene.beat_analyzer_props
    scene = context.scene
    
    if scene.sequence_editor:
        for sequence in scene.sequence_editor.sequences_all:
            if sequence.type == 'SOUND' and sequence.sound.filepath == props.audio_file:
                # Set the sequence mute state
                sequence.mute = mute_state
                props.audio_muted = mute_state
                return True
    return False

class BeatAnalyzerCache:
    """Cache system for storing analysis results"""
    _cache = {}
    _max_cache_size = 10

    @staticmethod
    def get_cache_key(file_path, settings):
        """Generate unique cache key based on file path and settings"""
        settings_hash = hash(frozenset(settings.items()))
        return f"{file_path}_{settings_hash}"

    @staticmethod
    def get_cached_result(file_path, settings):
        """Retrieve cached analysis results"""
        cache_key = BeatAnalyzerCache.get_cache_key(file_path, settings)
        return BeatAnalyzerCache._cache.get(cache_key)

    @staticmethod
    def store_result(file_path, settings, result):
        """Store analysis results in cache"""
        cache_key = BeatAnalyzerCache.get_cache_key(file_path, settings)
        if len(BeatAnalyzerCache._cache) >= BeatAnalyzerCache._max_cache_size:
            oldest_key = next(iter(BeatAnalyzerCache._cache))
            del BeatAnalyzerCache._cache[oldest_key]
        BeatAnalyzerCache._cache[cache_key] = result

def update_bake_preset(self, context):
        if self.bake_preset == 'CUSTOM':
            return
            
        # Preset values
        presets = {
            'KICK': {
                'low_freq': 20.0,
                'high_freq': 150.0,
                'attack_time': 0.005,
                'release_time': 0.2,
                'threshold': 0.1,
                'sthreshold': 0.2,
                'use_accumulate': False,
                'use_additive': False,
                'use_square': False,
                'bake_smoothing': 0.2
            },
            'SNARE': {
                'low_freq': 200.0,
                'high_freq': 2000.0,
                'attack_time': 0.001,
                'release_time': 0.1,
                'threshold': 0.15,
                'sthreshold': 0.25,
                'use_accumulate': False,
                'use_additive': True,
                'use_square': False,
                'bake_smoothing': 0.1
            },
            'HIHAT': {
                'low_freq': 5000.0,
                'high_freq': 20000.0,
                'attack_time': 0.001,
                'release_time': 0.05,
                'threshold': 0.2,
                'sthreshold': 0.3,
                'use_accumulate': False,
                'use_additive': True,
                'use_square': False,
                'bake_smoothing': 0.0
            },
            'BASS': {
                'low_freq': 20.0,
                'high_freq': 200.0,
                'attack_time': 0.02,
                'release_time': 0.3,
                'threshold': 0.05,
                'sthreshold': 0.15,
                'use_accumulate': True,
                'use_additive': False,
                'use_square': False,
                'bake_smoothing': 0.4
            },
            'VOCAL': {
                'low_freq': 200.0,
                'high_freq': 4000.0,
                'attack_time': 0.01,
                'release_time': 0.15,
                'threshold': 0.1,
                'sthreshold': 0.2,
                'use_accumulate': True,
                'use_additive': False,
                'use_square': False,
                'bake_smoothing': 0.3
            }
        }
        
        # Apply preset values
        if self.bake_preset in presets:
            preset = presets[self.bake_preset]
            for key, value in preset.items():
                setattr(self, key, value)

def update_frequency_ranges(self, context):
    props = context.scene.beat_analyzer_props
    
    # Define preset frequency ranges
    preset_ranges = {
        'KICK': {
            'low_freq': 60,
            'high_freq': 8000,
            'attack_time': 0.005,
            'release_time': 0.1,
            'threshold': 0.3,
            'sthreshold': 0.2
        },
        'SNARE': {
            'low_freq': 100,
            'high_freq': 10000,
            'attack_time': 0.001,
            'release_time': 0.08,
            'threshold': 0.25,
            'sthreshold': 0.15
        },
        'HIHAT': {
            'low_freq': 100,
            'high_freq': 16000,
            'attack_time': 0.001,
            'release_time': 0.05,
            'threshold': 0.2,
            'sthreshold': 0.1
        },
        'TOMS': {
            'low_freq': 80,
            'high_freq': 7000,
            'attack_time': 0.005,
            'release_time': 0.15,
            'threshold': 0.3,
            'sthreshold': 0.2
        },
        'OVERHEAD': {
            'low_freq': 50,
            'high_freq': 16000,
            'attack_time': 0.001,
            'release_time': 0.1,
            'threshold': 0.2,
            'sthreshold': 0.15
        }
    }
    
    # Update frequency ranges based on preset
    if props.bake_preset in preset_ranges:
        range_data = preset_ranges[props.bake_preset]
        props.low_freq = range_data['low_freq']
        props.high_freq = range_data['high_freq']
        props.attack_time = range_data['attack_time']
        props.release_time = range_data['release_time']
        props.threshold = range_data['threshold']
        props.sthreshold = range_data['sthreshold']


class BeatAnalyzerProperties(PropertyGroup):
    """Properties for the Beat Analyzer addon"""
    
    # Audio File Settings
    audio_file: StringProperty(
        name="Audio File", 
        description="Path to audio file",
        default=""
    )

    audio_muted: BoolProperty(
        name="Mute Audio",
        description="Mute/unmute the audio playback",
        default=False
    )

    clear_markers: BoolProperty(
        name="Clear Markers",
        description="Clear existing markers before analysis",
        default=True
    )

    # Analysis Method Settings
    detection_method: EnumProperty(
        name="Detection Method",
        description="Method used for beat detection",
        items=[
            ('ENERGY', "Energy Based", "Classic energy-based beat detection"),
            ('SPECTRAL', "Spectral Flux", "Detection using spectral flux"),
            ('COMPLEX', "Complex Detection", "Combined energy and spectral analysis"),
            ('ADAPTIVE', "Adaptive Threshold", "Adaptive threshold detection")
        ],
        default='COMPLEX'
    )

    frequency_bands: EnumProperty(
        name="Frequency Bands",
        description="Analyze specific frequency ranges",
        items=[
            ('ALL', "All Frequencies", "Analyze full spectrum"),
            ('BASS', "Bass Only", "Focus on low frequencies (20-250Hz)"),
            ('MID', "Mid Range", "Focus on mid frequencies (250-2000Hz)"),
            ('HIGH', "High Range", "Focus on high frequencies (2000-20000Hz)"),
            ('CUSTOM', "Custom Range", "Define custom frequency range")
        ],
        default='ALL'
    )
    
    custom_freq_low: FloatProperty(
        name="Low Frequency",
        description="Lower bound of frequency range (Hz)",
        default=20.0,
        min=20.0,
        max=20000.0
    )
    
    custom_freq_high: FloatProperty(
        name="High Frequency",
        description="Upper bound of frequency range (Hz)",
        default=20000.0,
        min=20.0,
        max=20000.0
    )

    # Analysis Parameters
    sensitivity: FloatProperty(
        name="Sensitivity",
        description="Beat detection sensitivity (lower = more beats)",
        default=1.3,
        min=0.1,
        max=2.0
    )

    min_bpm: IntProperty(
        name="Minimum BPM",
        description="Minimum beats per minute to detect",
        default=60,
        min=30,
        max=300
    )

    max_bpm: IntProperty(
        name="Maximum BPM",
        description="Maximum beats per minute to detect",
        default=180,
        min=30,
        max=300
    )

    analysis_window: IntProperty(
        name="Analysis Window",
        description="Size of analysis window in milliseconds",
        default=50,
        min=10,
        max=200
    )

    # Advanced Settings
    advanced_settings: BoolProperty(
        name="Advanced Settings",
        description="Show advanced analysis settings",
        default=False
    )

    use_threading: BoolProperty(
        name="Use Threading",
        description="Use multi-threading for analysis (faster but may be less stable)",
        default=True
    )

    use_cache: BoolProperty(
        name="Use Cache",
        description="Cache analysis results for faster repeated analysis",
        default=True
    )

    noise_reduction: FloatProperty(
        name="Noise Reduction",
        description="Reduce background noise (0 = off, 1 = maximum)",
        default=0.2,
        min=0.0,
        max=1.0
    )

    beat_refinement: BoolProperty(
        name="Beat Refinement",
        description="Additional processing to refine beat positions",
        default=True
    )

    debug_mode: BoolProperty(
        name="Debug Mode",
        description="Show additional debug information",
        default=False
    )

    # Beat Strength Settings
    strong_beat_threshold: FloatProperty(
        name="Strong Beat Threshold",
        description="Threshold for strong beat detection",
        default=1.5,
        min=1.0,
        max=3.0
    )

    medium_beat_threshold: FloatProperty(
        name="Medium Beat Threshold",
        description="Threshold for medium beat detection",
        default=1.2,
        min=1.0,
        max=3.0
    )

    # Marker Settings
    marker_prefix: StringProperty(
        name="Marker Prefix",
        description="Prefix for marker names",
        default="Beat_"
    )

    show_strong_beats: BoolProperty(
        name="Strong Beats",
        description="Show markers for strong beats",
        default=True
    )

    show_medium_beats: BoolProperty(
        name="Medium Beats",
        description="Show markers for medium beats",
        default=True
    )

    show_weak_beats: BoolProperty(
        name="Weak Beats",
        description="Show markers for weak beats",
        default=True
    )

    frame_offset: IntProperty(
        name="Frame Offset",
        description="Offset frames to compensate for latency",
        default=0,
        min=-10,
        max=10
    )

    bake_smoothing: FloatProperty(
        name="Smoothing",
        description="Smoothing factor for audio baking",
        default=0.5,
        min=0.0,
        max=1.0
    )

    create_shader_group: BoolProperty(
        name="Create Shader Group",
        description="Create a shader node group for easy audio visualization",
        default=True
    )

    shader_group_name: StringProperty(
        name="Shader Group Name",
        description="Name of the shader node group to create",
        default="Audio_Visualizer"
    )

    # Audio Baking Parameters
    low_freq: FloatProperty(
        name="Low Frequency",
        description="Low frequency cutoff for audio baking (Hz)",
        default=20.0,
        min=0.1,
        max=100000.0
    )
    
    high_freq: FloatProperty(
        name="High Frequency",
        description="High frequency cutoff for audio baking (Hz)",
        default=20000.0,
        min=0.1,
        max=100000.0
    )
    
    attack_time: FloatProperty(
        name="Attack Time",
        description="Time constant for attack phase (seconds)",
        default=0.005,
        min=0.001,
        max=2.0
    )
    
    release_time: FloatProperty(
        name="Release Time",
        description="Time constant for release phase (seconds)",
        default=0.2,
        min=0.001,
        max=5.0
    )
    
    threshold: FloatProperty(
        name="Threshold",
        description="Threshold for audio baking",
        default=0.0,
        min=0.0,
        max=1.0
    )
    
    sthreshold: FloatProperty(
        name="Secondary Threshold",
        description="Secondary threshold for audio baking",
        default=0.1,
        min=0.0,
        max=1.0
    )

    use_accumulate: BoolProperty(
        name="Accumulate",
        description="Accumulate values over time",
        default=False
    )
    
    use_additive: BoolProperty(
        name="Additive",
        description="Add values instead of generating absolute values",
        default=False
    )
    
    use_square: BoolProperty(
        name="Square",
        description="Square the output values",
        default=False
    )

    bake_preset: EnumProperty(
        name="Bake Preset",
        description="Preset configurations for audio baking",
        items=[
            ('CUSTOM', "Custom", "Custom frequency settings"),
            ('KICK', "Kick", "Kick drum frequencies"),
            ('SNARE', "Snare", "Snare drum frequencies"),
            ('HIHAT', "Hi-Hat", "Hi-hat and cymbal frequencies"),
            ('TOMS', "Toms", "Tom drums frequencies"),
            ('OVERHEAD', "Overhead", "Overhead microphone frequencies"),
            ('BASS', "Bass", "Bass frequencies"),
            ('VOCAL', "Vocal", "Vocal frequencies")
        ],
        default='CUSTOM',
        update=update_bake_preset
    )

    freq_band_focus: EnumProperty(
        name="Frequency Focus",
        description="Specific frequency band to focus on",
        items=[
            ('FULL', "Full Range", "Full frequency range"),
            ('SUB', "Sub", "Sub frequencies (20-60Hz)"),
            ('THUMP', "Thump", "Thump range (60-100Hz)"),
            ('WARMTH', "Warmth", "Warm frequencies (100-250Hz)"),
            ('BOX', "Box", "Box frequencies (400-1000Hz)"),
            ('ATTACK', "Attack", "Attack frequencies (2-8kHz)"),
            ('PRESENCE', "Presence", "Presence range (4-8kHz)"),
            ('CRISP', "Crisp", "Crisp frequencies (8-12kHz)"),
            ('AIR', "Air", "Air frequencies (12kHz+)")
        ],
        default='FULL'
    )

    # Analysis Results Storage
    total_beats: IntProperty(default=0)
    average_bpm: FloatProperty(default=0.0)
    audio_duration: FloatProperty(default=0.0)
    last_analysis_time: StringProperty(default="Never")
    debug_info: StringProperty(default="No analysis performed yet")


class AudioAnalysisThread(threading.Thread):
    def __init__(self, file_path, props):
        threading.Thread.__init__(self)
        self.file_path = file_path
        self.props = props
        self.results = None
        self.error = None
        self.progress = 0
        
        # Initialize analysis parameters
        self.sample_rate = 0
        self.channels = 0
        self.window_size = int(props.analysis_window * 44100 / 1000)  # Convert ms to samples
        self.hop_length = self.window_size // 2
        
        # Copy properties for thread-safe access
        self.low_freq = props.low_freq
        self.high_freq = props.high_freq
        self.attack_time = props.attack_time
        self.release_time = props.release_time
        self.threshold = props.threshold
        self.sthreshold = props.sthreshold
        self.use_accumulate = props.use_accumulate
        self.use_additive = props.use_additive
        self.use_square = props.use_square
        self.bake_smoothing = props.bake_smoothing

    def run(self):
        try:
            analyzer = AudioAnalyzer(self.props)
            self.results = analyzer.analyze_file(
                self.file_path,
                progress_callback=self.update_progress
            )
                  
        except Exception as e:
            self.error = str(e)

    def update_progress(self, progress):
        self.progress = progress

    def cancel(self):
        self.is_cancelled = True

class AudioAnalyzer:
    """Main audio analysis class"""
    def __init__(self, props):
        self.props = props
        self.sample_rate = 0
        self.channels = 0
        self.window_size = 1024
        self.hop_length = 512

    def analyze_file(self, file_path, progress_callback=None):
        """Main analysis function"""
        try:
            # Read audio file more efficiently
            with wave.open(file_path, 'rb') as wf:
                self.sample_rate = wf.getframerate()
                self.channels = wf.getnchannels()
                n_frames = wf.getnframes()
                audio_data = wf.readframes(n_frames)
                
                # Convert to numpy array with explicit dtype
                data = np.frombuffer(audio_data, dtype=np.int16)
                if self.channels == 2:
                    data = data.reshape(-1, 2).mean(axis=1)
                
                # Ensure data is float32 type
                data = data.astype(np.float32) / 32768.0

            # Apply frequency band filtering
            data = self.apply_frequency_filter(data)

            # Apply noise reduction if enabled
            if self.props.noise_reduction > 0:
                data = self.apply_noise_reduction(data)

            # Get beats based on selected method
            if self.props.detection_method == 'ENERGY':
                beats = self.energy_based_detection(data, progress_callback)
            elif self.props.detection_method == 'SPECTRAL':
                beats = self.spectral_flux_detection(data, progress_callback)
            elif self.props.detection_method == 'COMPLEX':
                beats = self.complex_detection(data, progress_callback)
            else:  # ADAPTIVE
                beats = self.adaptive_threshold_detection(data, progress_callback)

            # Ensure beats are properly formatted
            beats = [(float(time), str(strength)) for time, strength in beats]

            # Calculate audio statistics
            duration = float(len(data)) / float(self.sample_rate)
            bpm = float(len(beats)) * 60.0 / duration if beats else 0.0

            return {
                'beats': beats,
                'audio_info': {
                    'duration': float(duration),
                    'sample_rate': int(self.sample_rate),
                    'channels': int(self.channels),
                    'bpm': float(bpm)
                }
            }

        except Exception as e:
            raise RuntimeError(f"Analysis failed: {str(e)}")

    def apply_frequency_filter(self, data):
        """Apply frequency band filtering based on settings"""
        if self.props.frequency_bands == 'ALL':
            return data

        # Calculate FFT
        fft_data = np.fft.rfft(data)
        freqs = np.fft.rfftfreq(len(data), 1/self.sample_rate)
        
        # Create frequency mask
        mask = np.ones_like(freqs, dtype=bool)
        
        if self.props.frequency_bands == 'BASS':
            mask = (freqs >= 20) & (freqs <= 250)
        elif self.props.frequency_bands == 'MID':
            mask = (freqs >= 250) & (freqs <= 2000)
        elif self.props.frequency_bands == 'HIGH':
            mask = (freqs >= 2000) & (freqs <= 20000)
        elif self.props.frequency_bands == 'CUSTOM':
            mask = (freqs >= self.props.custom_freq_low) & (freqs <= self.props.custom_freq_high)

        # Apply mask and inverse FFT
        fft_data[~mask] = 0
        return np.fft.irfft(fft_data)

    def apply_noise_reduction(self, data):
        """Apply noise reduction to the audio data"""
        if self.props.noise_reduction <= 0:
            return data

        # Estimate noise profile from the quietest sections
        frame_length = 2048
        noise_profile = []
        for i in range(0, len(data) - frame_length, frame_length):
            frame = data[i:i + frame_length]
            frame_energy = np.sum(frame ** 2)
            noise_profile.append(frame_energy)

        noise_threshold = np.percentile(noise_profile, 10)
        
        # Apply noise gate with smoothing
        data_clean = data.copy()
        mask = abs(data_clean) < (noise_threshold * self.props.noise_reduction)
        data_clean[mask] = data_clean[mask] * (1 - self.props.noise_reduction)
        
        return data_clean

    def energy_based_detection(self, data, progress_callback):
        beats = []
        window_size = int(self.props.analysis_window * self.sample_rate / 2000)  # Reduced window size
        hop_length = window_size // 4  # Smaller hop length for better accuracy
        
        # Pre-calculate energy windows using numpy operations
        windows = np.array([data[i:i + window_size] for i in range(0, len(data) - window_size, hop_length)])
        energies = np.sum(windows ** 2, axis=1)
        
        # Calculate threshold more efficiently
        threshold = np.mean(energies) * self.props.sensitivity
        
        # Find peaks using numpy operations
        peak_mask = (energies[1:-1] > threshold) & (energies[1:-1] > energies[:-2]) & (energies[1:-1] > energies[2:])
        peak_indices = np.where(peak_mask)[0] + 1
        
        # Convert peaks to beats
        for i in peak_indices:
            beat_time = (i * hop_length) / self.sample_rate
            beat_strength = energies[i] / threshold
            beats.append((beat_time, self.categorize_beat_strength(beat_strength)))
        
        return beats

    def spectral_flux_detection(self, data, progress_callback):
        """Beat detection using spectral flux"""
        # Compute spectrogram more efficiently
        spectrogram = self.compute_spectrogram(data, progress_callback)
        
        # Calculate spectral flux using numpy operations
        flux = np.diff(spectrogram, axis=0)
        flux = np.maximum(flux, 0)
        flux = np.sum(flux, axis=1)
        
        # Normalize flux
        flux = flux / (np.max(flux) + 1e-6)  # Added small constant to prevent division by zero
    
        # Find peaks more efficiently
        threshold = np.mean(flux) * self.props.sensitivity
        peaks = []
        
        # Vectorized peak finding
        peak_mask = (flux[1:-1] > threshold) & (flux[1:-1] > flux[:-2]) & (flux[1:-1] > flux[2:])
        peak_indices = np.where(peak_mask)[0] + 1
        
        for i in peak_indices:
            beat_time = (i * self.hop_length) / self.sample_rate
            beat_strength = flux[i] / threshold
            peaks.append((beat_time, self.categorize_beat_strength(beat_strength)))
    
        return peaks
    
    def complex_detection(self, data, progress_callback):
        """Combined energy and spectral analysis"""
        # Split progress callback
        if progress_callback:
            energy_callback = lambda p: progress_callback(float(p)/2)
            spectral_callback = lambda p: progress_callback(50.0 + float(p)/2)
        else:
            energy_callback = spectral_callback = None

        # Get beats from both methods
        energy_beats = self.energy_based_detection(data, energy_callback)
        spectral_beats = self.spectral_flux_detection(data, spectral_callback)

        # Combine beats and convert to proper types
        all_beats = [(float(time), str(strength)) for time, strength in (energy_beats + spectral_beats)]
        
        if not all_beats:
            return []

        # Sort by time
        all_beats.sort(key=lambda x: x[0])

        # Remove duplicates and close beats
        min_beat_distance = 60.0 / float(self.props.max_bpm)
        filtered_beats = []
        last_beat_time = -min_beat_distance

        for beat_time, strength in all_beats:
            if beat_time - last_beat_time >= min_beat_distance:
                filtered_beats.append((beat_time, strength))
                last_beat_time = beat_time

        return filtered_beats
    
    def adaptive_threshold_detection(self, data, progress_callback):
        """Beat detection with adaptive thresholding"""
        window_size = int(self.props.analysis_window * self.sample_rate / 1000)
        hop_length = window_size // 2
    
        # Calculate local energy more efficiently
        windows = np.array([data[i:i + window_size] for i in range(0, len(data) - window_size, hop_length)])
        energies = np.sum(windows ** 2, axis=1)
    
        # Calculate adaptive threshold using convolution
        kernel_size = int(2 * self.sample_rate / hop_length)
        kernel_size = kernel_size if kernel_size % 2 == 1 else kernel_size + 1
        kernel = np.ones(kernel_size) / kernel_size
        threshold = np.convolve(energies, kernel, mode='same') * self.props.sensitivity
    
        # Find peaks efficiently
        peak_mask = (energies[1:-1] > threshold[1:-1]) & \
                    (energies[1:-1] > energies[:-2]) & \
                    (energies[1:-1] > energies[2:])
        peak_indices = np.where(peak_mask)[0] + 1
    
        beats = []
        for i in peak_indices:
            beat_time = (i * hop_length) / self.sample_rate
            beat_strength = energies[i] / threshold[i]
            beats.append((beat_time, self.categorize_beat_strength(beat_strength)))
    
        return beats
    

    def categorize_beat_strength(self, strength):
        """Categorize beat strength based on thresholds"""
        if strength >= self.props.strong_beat_threshold:
            return 'strong'
        elif strength >= self.props.medium_beat_threshold:
            return 'medium'
        return 'weak'

    def compute_spectrogram(self, data, progress_callback=None):
        """Compute spectrogram using STFT"""
        spectrogram = []
        window = np.hanning(self.window_size)

        for i in range(0, len(data) - self.window_size, self.hop_length):
            if progress_callback:
                progress = (i / len(data)) * 100
                progress_callback(progress)

            windowed = data[i:i + self.window_size] * window
            spectrum = np.abs(np.fft.rfft(windowed))
            spectrogram.append(spectrum)

        return np.array(spectrogram)

    def refine_beats(self, data, beats):
        """Refine beat positions by looking for local maxima"""
        if not beats:
            return beats
            
        refined_beats = []
        window_size = int(0.05 * self.sample_rate)  # 50ms window
        
        for beat_time, strength in beats:
            center_idx = int(beat_time * self.sample_rate)
            start_idx = max(0, center_idx - window_size // 2)
            end_idx = min(len(data), center_idx + window_size // 2)
            
            window = data[start_idx:end_idx]
            
            if len(window) > 0:
                local_energies = window ** 2
                max_energy_idx = np.argmax(local_energies)
                refined_time = (start_idx + max_energy_idx) / self.sample_rate
                refined_beats.append((refined_time, strength))
        
        refined_beats.sort(key=lambda x: x[0])
        
        # Remove beats that are too close together
        min_beat_distance = 60 / self.props.max_bpm
        filtered_beats = []
        last_beat_time = -min_beat_distance
        
        for beat_time, strength in refined_beats:
            if beat_time - last_beat_time >= min_beat_distance:
                filtered_beats.append((beat_time, strength))
                last_beat_time = beat_time
        
        return filtered_beats
    
class BEATANALYZER_OT_browse_audio(Operator):
    bl_idname = "beatanalyzer.browse_audio"
    bl_label = "Browse Audio File"
    
    filename_ext = ".wav"
    filter_glob: StringProperty(default="*.wav", options={'HIDDEN'})
    filepath: StringProperty(subtype='FILE_PATH')
    
    def execute(self, context):
        props = context.scene.beat_analyzer_props
        props.audio_file = self.filepath
        return {'FINISHED'}
    
    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

class BEATANALYZER_OT_analyze(Operator):
    bl_idname = "beatanalyzer.analyze"
    bl_label = "Analyze Audio"
    bl_description = "Perform beat analysis on selected audio file"
    bl_options = {'REGISTER', 'UNDO'}

    _timer = None
    _analysis_thread = None

    def modal(self, context, event):
        if event.type == 'TIMER':
            if self._analysis_thread and self._analysis_thread.is_alive():
                # Update progress bar
                wm = context.window_manager
                wm.progress_update(self._analysis_thread.progress)
                return {'RUNNING_MODAL'}
            
            elif self._analysis_thread:
                # Analysis completed
                wm = context.window_manager
                wm.progress_end()
                
                if self._analysis_thread.error:
                    self.report({'ERROR'}, self._analysis_thread.error)
                    return {'CANCELLED'}
                
                if self._analysis_thread.results:
                    self.apply_results(context, self._analysis_thread.results)
                
                wm.event_timer_remove(self._timer)
                self._analysis_thread = None
                return {'FINISHED'}
        
        return {'PASS_THROUGH'}

    def clear_markers(self, context):
        """Helper function to safely clear markers"""
        scene = context.scene
        
        # Direct method to remove markers
        while scene.timeline_markers:
            scene.timeline_markers.remove(scene.timeline_markers[0])
    
    def execute(self, context):
        props = context.scene.beat_analyzer_props
        
        if not props.audio_file:
            self.report({'ERROR'}, "No audio file selected")
            return {'CANCELLED'}
            
        if not os.path.exists(props.audio_file):
            self.report({'ERROR'}, f"File not found: {props.audio_file}")
            return {'CANCELLED'}
    
        # Add audio to sequencer
        self.add_audio_to_sequencer(context)
    
        # Check cache first
        if props.use_cache:
            settings = self.get_analysis_settings(props)
            cached_result = BeatAnalyzerCache.get_cached_result(props.audio_file, settings)
            if cached_result:
                self.apply_results(context, cached_result)
                return {'FINISHED'}
    
        # Clear existing markers using direct method
        self.clear_markers(context)
    
        # Start analysis thread
        self._analysis_thread = AudioAnalysisThread(props.audio_file, props)
        self._analysis_thread.start()
    
        # Start modal timer
        wm = context.window_manager
        self._timer = wm.event_timer_add(0.1, window=context.window)
        wm.progress_begin(0, 100)
        wm.modal_handler_add(self)
    
        return {'RUNNING_MODAL'}

    def add_audio_to_sequencer(self, context):
        scene = context.scene
        props = scene.beat_analyzer_props
        
        # Create sequence editor if it doesn't exist
        if not scene.sequence_editor:
            scene.sequence_editor_create()
        
        # Check if audio already exists
        for seq in scene.sequence_editor.sequences_all:
            if seq.type == 'SOUND' and seq.sound.filepath == props.audio_file:
                seq.mute = props.audio_muted
                return  # Audio already exists
    
        try:
            # First attempt: Direct method using sequences
            sequence_editor = scene.sequence_editor
            soundstrip = sequence_editor.sequences.new_sound(
                name=os.path.basename(props.audio_file),
                filepath=props.audio_file,
                channel=1,
                frame_start=1
            )
            soundstrip.mute = props.audio_muted
            
        except Exception as e:
            print(f"Direct method failed: {str(e)}")
            try:
                # Second attempt: Using operator with area override
                override = context.copy()
                
                # Try to find sequence editor area
                sequence_area = None
                for window in context.window_manager.windows:
                    for area in window.screen.areas:
                        if area.type == 'SEQUENCE_EDITOR':
                            sequence_area = area
                            break
                    if sequence_area:
                        break
                
                # If no sequence editor is found, try to use current area
                if not sequence_area and context.area:
                    sequence_area = context.area
                
                if sequence_area:
                    # Set up override context
                    override = {
                        "window": context.window,
                        "screen": context.screen,
                        "area": sequence_area,
                        "region": sequence_area.regions[0] if sequence_area.regions else None,
                        "scene": scene
                    }
                    
                    # Add sound strip using operator
                    bpy.ops.sequencer.sound_strip_add(
                        override,
                        filepath=props.audio_file,
                        frame_start=1,
                        channel=1
                    )
                    
                    # Set mute state for newly added audio
                    for seq in scene.sequence_editor.sequences_all:
                        if seq.type == 'SOUND' and seq.sound.filepath == props.audio_file:
                            seq.mute = props.audio_muted
                            break
                            
            except Exception as e:
                print(f"Operator method failed: {str(e)}")
                # Final attempt: Most basic approach
                try:
                    bpy.ops.sequencer.sound_strip_add(
                        filepath=props.audio_file,
                        frame_start=1,
                        channel=1
                    )
                    
                    # Set mute state
                    for seq in scene.sequence_editor.sequences_all:
                        if seq.type == 'SOUND' and seq.sound.filepath == props.audio_file:
                            seq.mute = props.audio_muted
                            break
                            
                except Exception as e:
                    print(f"All methods failed: {str(e)}")
                    self.report({'ERROR'}, "Failed to add audio to sequencer")  

    def get_analysis_settings(self, props):
        return {
            'detection_method': props.detection_method,
            'frequency_bands': props.frequency_bands,
            'sensitivity': props.sensitivity,
            'noise_reduction': props.noise_reduction,
            'analysis_window': props.analysis_window,
            'min_bpm': props.min_bpm,
            'max_bpm': props.max_bpm,
            'low_freq': props.low_freq,
            'high_freq': props.high_freq,
            'attack_time': props.attack_time,
            'release_time': props.release_time,
            'threshold': props.threshold,
            'sthreshold': props.sthreshold,
            'use_accumulate': props.use_accumulate,
            'use_additive': props.use_additive,
            'use_square': props.use_square,
            'bake_smoothing': props.bake_smoothing
        }

    def apply_results(self, context, results):
        props = context.scene.beat_analyzer_props
        scene = context.scene
        fps = scene.render.fps
        
        # Pre-filter beats based on strength
        filtered_beats = [
            (time, strength) for time, strength in results['beats']
            if ((strength == 'strong' and props.show_strong_beats) or
                (strength == 'medium' and props.show_medium_beats) or
                (strength == 'weak' and props.show_weak_beats))
        ]
        
        # Create all markers at once
        scene.timeline_markers.clear()
        for time, strength in filtered_beats:
            frame = int(time * fps) + props.frame_offset
            scene.timeline_markers.new(f"{props.marker_prefix}{frame}_{strength}", frame=frame)
        
        # Update properties
        props.total_beats = len(results['beats'])
        props.average_bpm = results['audio_info']['bpm']
        props.audio_duration = results['audio_info']['duration']
        props.last_analysis_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
        
        # Update debug info
        if props.debug_mode:
            props.debug_info = (
                f"Sample Rate: {results['audio_info']['sample_rate']} Hz\n"
                f"Channels: {results['audio_info']['channels']}\n"
                f"Duration: {results['audio_info']['duration']:.2f} seconds\n"
                f"Total Beats: {props.total_beats}\n"
                f"Average BPM: {props.average_bpm:.1f}"
            )

        # Cache results if enabled
        if props.use_cache:
            settings = self.get_analysis_settings(props)
            BeatAnalyzerCache.store_result(props.audio_file, settings, results)

class BEATANALYZER_OT_bake_to_shader(Operator):
    bl_idname = "beatanalyzer.bake_to_shader"
    bl_label = "Bake to AVS"
    bl_description = "Bake audio to Audio Value Shader node"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.active_object is not None

    def find_or_create_value_setup(self, context, target_type):
        obj = context.active_object
        props = context.scene.beat_analyzer_props
        value_nodes = []
        node_trees = []

        # Handle Material Nodes (Shader Editor)
        if not obj.active_material:
            mat = bpy.data.materials.new(name=f"Audio_{props.bake_preset}")
            mat.use_nodes = True
            obj.active_material = mat
        else:
            mat = obj.active_material
            mat.use_nodes = True

        shader_tree = mat.node_tree
        value_node = None
        
        # Check existing material nodes
        for node in shader_tree.nodes:
            if node.type == 'VALUE' and node.label == f"Audio_{props.bake_preset}":
                value_node = node
                break
        
        # If not found, create new setup
        if not value_node:
            # Create nodes
            value_node = shader_tree.nodes.new('ShaderNodeValue')
            value_node.label = f"Audio_{props.bake_preset}"
            value_node.name = f"Audio_{props.bake_preset}"
            
            noise_tex = shader_tree.nodes.new('ShaderNodeTexNoise')
            noise_tex.noise_dimensions = '4D'
            
            color_ramp = shader_tree.nodes.new('ShaderNodeValToRGB')
            principled = shader_tree.nodes.new('ShaderNodeBsdfPrincipled')
            output = shader_tree.nodes.new('ShaderNodeOutputMaterial')
            
            # Position nodes
            value_node.location = (-600, 0)
            noise_tex.location = (-400, 0)
            color_ramp.location = (-200, 0)
            principled.location = (0, 0)
            output.location = (200, 0)
            
            # Link nodes
            shader_tree.links.new(value_node.outputs[0], noise_tex.inputs['W'])
            shader_tree.links.new(noise_tex.outputs['Fac'], color_ramp.inputs[0])
            shader_tree.links.new(color_ramp.outputs[0], principled.inputs['Emission Color'])
            shader_tree.links.new(principled.outputs[0], output.inputs[0])
            
            # Set up color ramp based on preset
            if props.bake_preset == 'KICK':
                color_ramp.color_ramp.elements[0].color = (0, 0, 0.2, 1)
                color_ramp.color_ramp.elements[1].color = (0, 0.5, 1, 1)
            elif props.bake_preset == 'SNARE':
                color_ramp.color_ramp.elements[0].color = (0.2, 0, 0, 1)
                color_ramp.color_ramp.elements[1].color = (1, 0.5, 0, 1)
            elif props.bake_preset == 'HIHAT':
                color_ramp.color_ramp.elements[0].color = (0.2, 0.2, 0, 1)
                color_ramp.color_ramp.elements[1].color = (1, 1, 0, 1)
            else:
                color_ramp.color_ramp.elements[0].color = (0, 0, 0, 1)
                color_ramp.color_ramp.elements[1].color = (1, 1, 1, 1)
            
            # Set up Principled BSDF
            principled.inputs['Emission Strength'].default_value = 2.0

        value_nodes.append(value_node)
        node_trees.append(shader_tree)

        return value_nodes, node_trees

    def execute(self, context):
        props = context.scene.beat_analyzer_props

        if not context.active_object:
            self.report({'WARNING'}, "No active object selected")
            return {'CANCELLED'}

        if not props.audio_file or not os.path.exists(props.audio_file):
            self.report({'WARNING'}, "No valid audio file selected")
            return {'CANCELLED'}
    
        try:
            value_nodes, node_trees = self.find_or_create_value_setup(context, 'SHADER')
            
            if not value_nodes:
                self.report({'WARNING'}, "Could not create shader value node")
                return {'CANCELLED'}

            value_node = value_nodes[0]
            node_tree = node_trees[0]

            if not node_tree.animation_data:
                node_tree.animation_data_create()
            
            action_name = f"AudioAnimation_{props.bake_preset}_{value_node.name}"
            action = bpy.data.actions.new(name=action_name)
            node_tree.animation_data.action = action

            # Clear existing fcurves
            fcurves = action.fcurves
            for fc in fcurves[:]:
                if value_node.name in fc.data_path:
                    fcurves.remove(fc)

            value_node.outputs[0].default_value = 0
            value_node.outputs[0].keyframe_insert(data_path="default_value", frame=1)

            fcurve = None
            for fc in action.fcurves:
                if "default_value" in fc.data_path and value_node.name in fc.data_path:
                    fcurve = fc
                    break

            if not fcurve:
                self.report({'ERROR'}, "Could not create F-Curve")
                return {'CANCELLED'}

            fcurve.select = True
            fcurve.hide = False

            # Get the graph editor
            screen = context.screen
            if not screen:
                self.report({'ERROR'}, "No screen found")
                return {'CANCELLED'}

            # Find or create a temporary graph editor area
            temp_area = None
            original_type = None
            
            for area in screen.areas:
                if area.type == 'GRAPH_EDITOR':
                    temp_area = area
                    break
            
            if not temp_area:
                temp_area = context.area
                original_type = temp_area.type
                temp_area.type = 'GRAPH_EDITOR'

            # Bake sound with preset-specific settings
            if props.bake_preset == 'KICK':
                bpy.ops.graph.sound_to_samples(
                    filepath=props.audio_file,
                    low=60,
                    high=250,
                    attack=0.005,
                    release=0.2,
                    threshold=0.3,
                    use_accumulate=True,
                    use_additive=False,
                    use_square=False,
                    filter_sound=True
                )
            elif props.bake_preset == 'SNARE':
                bpy.ops.graph.sound_to_samples(
                    filepath=props.audio_file, 
                    low=200,
                    high=4000,
                    attack=0.001,
                    release=0.1,
                    threshold=0.2,
                    use_accumulate=False,
                    use_additive=True,
                    use_square=False,
                    filter_sound=True
                )
            elif props.bake_preset == 'HIHAT':
                bpy.ops.graph.sound_to_samples(
                    filepath=props.audio_file,
                    low=8000,
                    high=16000,
                    attack=0.001,
                    release=0.05,
                    threshold=0.15,
                    use_accumulate=True,
                    use_additive=True,
                    use_square=False,
                    filter_sound=True
                )
            else:
                bpy.ops.graph.sound_to_samples(
                    filepath=props.audio_file,
                    low=props.low_freq,
                    high=props.high_freq,
                    attack=props.attack_time,
                    release=props.release_time,
                    threshold=props.threshold,
                    use_accumulate=props.use_accumulate,
                    use_additive=props.use_additive,
                    use_square=props.use_square,
                    filter_sound=True
                )

            # Add modifiers based on preset
            for mod in fcurve.modifiers:
                fcurve.modifiers.remove(mod)
            
            env_mod = fcurve.modifiers.new('ENVELOPE')
            limit_mod = fcurve.modifiers.new('LIMITS')
            
            if props.bake_preset == 'KICK':
                env_mod.reference_value = 0.0
                env_mod.influence = props.bake_smoothing / 30.0
                limit_mod.min_y = -1.5
                limit_mod.max_y = 1.5
                
            elif props.bake_preset == 'SNARE':
                env_mod.reference_value = 0.0
                env_mod.influence = props.bake_smoothing / 25.0
                limit_mod.min_y = -2.0
                limit_mod.max_y = 2.0
                
            elif props.bake_preset == 'HIHAT':
                env_mod.reference_value = 0.0
                env_mod.influence = props.bake_smoothing / 15.0
                limit_mod.min_y = -3.0
                limit_mod.max_y = 3.0
                
            else:
                env_mod.reference_value = 0.5
                env_mod.influence = props.bake_smoothing / 10.0
                limit_mod.min_y = 0.0
                limit_mod.max_y = 5.0

            # Restore original area type if we changed it
            if original_type:
                temp_area.type = original_type  

            self.report({'INFO'}, f"Audio baked to {props.bake_preset} shader node")
            return {'FINISHED'}
            
        except Exception as e:
            self.report({'ERROR'}, f"Operation failed: {str(e)}")
            return {'CANCELLED'}

class BEATANALYZER_OT_bake_to_geometry(Operator):
    bl_idname = "beatanalyzer.bake_to_geometry"
    bl_label = "Bake to AVG" 
    bl_description = "Bake audio to Audio Value Geometry node"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.active_object is not None

    def find_or_create_value_setup(self, context, target_type):
        obj = context.active_object
        props = context.scene.beat_analyzer_props
        value_nodes = []
        node_trees = []

        # Handle Geometry Nodes
        # Check if geometry nodes modifier exists
        geo_mod = None
        for mod in obj.modifiers:
            if mod.type == 'NODES':
                geo_mod = mod
                break

        if not geo_mod:
            # Create new geometry nodes modifier
            geo_mod = obj.modifiers.new(name=f"Audio_{props.bake_preset}", type='NODES')
            
        if not geo_mod.node_group:
            # Create new node group if none exists
            geo_mod.node_group = bpy.data.node_groups.new(f"Audio_{props.bake_preset}", 'GeometryNodeTree')
            
        geo_tree = geo_mod.node_group
        value_node = None
        
        # Check existing geometry nodes
        for node in geo_tree.nodes:
            if node.type == 'VALUE' and node.label.startswith(f"Audio_{props.bake_preset}"):
                value_node = node
                break
                
        # If not found, create new setup
        if not value_node:
            # Find or create input/output nodes
            group_in = None
            group_out = None
            for node in geo_tree.nodes:
                if node.type == 'GROUP_INPUT':
                    group_in = node
                elif node.type == 'GROUP_OUTPUT':
                    group_out = node
            
            if not group_in:
                group_in = geo_tree.nodes.new('NodeGroupInput')
                group_in.location = (-600, 0)
            
            if not group_out:
                group_out = geo_tree.nodes.new('NodeGroupOutput')
                group_out.location = (400, 0)
            
            # Create audio visualization nodes
            value_node = geo_tree.nodes.new('ShaderNodeValue')
            value_node.label = f"Audio_{props.bake_preset}"
            value_node.name = f"Audio_{props.bake_preset}"
            
            # Create geometry node setup based on preset
            if props.bake_preset == 'KICK':
                noise_tex = geo_tree.nodes.new('ShaderNodeTexNoise')
                noise_tex.noise_dimensions = '4D'
                
                
            elif props.bake_preset == 'SNARE':
                noise_tex = geo_tree.nodes.new('ShaderNodeTexNoise') 
                noise_tex.noise_dimensions = '4D'
                
            elif props.bake_preset == 'HIHAT':
                noise_tex = geo_tree.nodes.new('ShaderNodeTexNoise')
                noise_tex.noise_dimensions = '4D' 

            elif props.bake_preset == 'BASS':
                noise_tex = geo_tree.nodes.new('ShaderNodeTexNoise')
                noise_tex.noise_dimensions = '4D' 
                
            else: # Custom/default
                noise_tex = geo_tree.nodes.new('NodeNoiseTexture')
                noise_tex.noise_dimensions = '4D'
            
            # Position the new nodes
            value_node.location = (-400, -300)
            noise_tex.location = (-200, -300)
            
            # Connect nodes
            geo_tree.links.new(value_node.outputs[0], noise_tex.inputs['W'])
            
            
            # Create default geometry pass-through
            if len(group_in.outputs) == 0:
                geo_tree.inputs.new('NodeSocketGeometry', "Geometry")
            if len(group_out.inputs) == 0:
                geo_tree.outputs.new('NodeSocketGeometry', "Geometry")

            # Only create link if sockets exist and aren't already connected
            if ('Geometry' in group_in.outputs and 'Geometry' in group_out.inputs and 
                not group_out.inputs['Geometry'].is_linked):
                geo_tree.links.new(group_in.outputs['Geometry'], group_out.inputs['Geometry'])

        value_nodes.append(value_node)
        node_trees.append(geo_tree)

        return value_nodes, node_trees

    def manage_fcurves(self, action, value_node):
        # Remove existing fcurves for the node
        existing_fcurves = [fc for fc in action.fcurves 
                           if value_node.name in fc.data_path]
        for fc in existing_fcurves:
            action.fcurves.remove(fc)
        
        # Create new fcurve
        data_path = f'nodes["{value_node.name}"].outputs[0].default_value'
        return action.fcurves.new(data_path=data_path)

    def execute(self, context):
        props = context.scene.beat_analyzer_props

        # Basic checks
        if not context.active_object:
            self.report({'WARNING'}, "No active object selected. Please select an object first.")
            return {'CANCELLED'}

        if not props.audio_file or not os.path.exists(props.audio_file):
            self.report({'WARNING'}, "No valid audio file selected.")
            return {'CANCELLED'}
    
        try:
            # Find or create value nodes for geometry only
            value_nodes, node_trees = self.find_or_create_value_setup(context, 'GEOMETRY')
            
            if not value_nodes:
                self.report({'WARNING'}, "Could not create or find geometry value node")
                return {'CANCELLED'}

            value_node = value_nodes[0]
            node_tree = node_trees[0]

            # Ensure animation data exists
            if not node_tree.animation_data:
                node_tree.animation_data_create()
            
            # Create or get action
            action_name = f"AudioAnimation_{props.bake_preset}_{value_node.name}"
            action = bpy.data.actions.new(name=action_name)
            node_tree.animation_data.action = action

            # Clear existing fcurves for this node
            fcurves = action.fcurves
            for fc in fcurves[:]:
                if value_node.name in fc.data_path:
                    fcurves.remove(fc)

            # Insert keyframe at frame 1
            value_node.outputs[0].default_value = 0
            value_node.outputs[0].keyframe_insert(data_path="default_value", frame=1)

            # Get the created fcurve
            fcurve = None
            for fc in action.fcurves:
                if "default_value" in fc.data_path and value_node.name in fc.data_path:
                    fcurve = fc
                    break

            if not fcurve:
                self.report({'ERROR'}, "Could not create F-Curve for audio baking")
                return {'CANCELLED'}

            # Make the fcurve active and visible
            fcurve.select = True
            fcurve.hide = False

            # Get the graph editor
            screen = context.screen
            if not screen:
                self.report({'ERROR'}, "No screen found")
                return {'CANCELLED'}

            # Find or create a temporary graph editor area
            temp_area = None
            original_type = None
            
            for area in screen.areas:
                if area.type == 'GRAPH_EDITOR':
                    temp_area = area
                    break
            
            if not temp_area:
                temp_area = context.area
                original_type = temp_area.type
                temp_area.type = 'GRAPH_EDITOR'

            try:
                # Bake sound to fcurve with preset-specific settings
                if props.bake_preset == 'KICK':
                    bpy.ops.graph.sound_to_samples(
                        filepath=props.audio_file,
                        low=60,
                        high=250,
                        attack=0.005,
                        release=0.2,
                        threshold=0.3,
                        use_accumulate=True,
                        use_additive=False,
                        use_square=False,
                        filter_sound=True
                    )
                elif props.bake_preset == 'SNARE':
                    bpy.ops.graph.sound_to_samples(
                        filepath=props.audio_file,
                        low=200,
                        high=4000,
                        attack=0.001,
                        release=0.1,
                        threshold=0.2,
                        use_accumulate=False,
                        use_additive=True,
                        use_square=False,
                        filter_sound=True
                    )
                elif props.bake_preset == 'HIHAT':
                    bpy.ops.graph.sound_to_samples(
                        filepath=props.audio_file,
                        low=8000,
                        high=16000,
                        attack=0.001,
                        release=0.05,
                        threshold=0.15,
                        use_accumulate=True,
                        use_additive=True,
                        use_square=False,
                        filter_sound=True
                    )
                else:
                    # Custom/default settings
                    bpy.ops.graph.sound_to_samples(
                        filepath=props.audio_file,
                        low=props.low_freq,
                        high=props.high_freq,
                        attack=props.attack_time,
                        release=props.release_time,
                        threshold=props.threshold,
                        sthreshold=props.sthreshold,
                        use_accumulate=props.use_accumulate,
                        use_additive=props.use_additive,
                        use_square=props.use_square,
                        filter_sound=True
                    )

                # Add modifiers based on preset
                for mod in fcurve.modifiers:
                    fcurve.modifiers.remove(mod)
                
                env_mod = fcurve.modifiers.new('ENVELOPE')
                limit_mod = fcurve.modifiers.new('LIMITS')
                
                if props.bake_preset == 'KICK':
                    env_mod.reference_value = 0.0
                    env_mod.influence = props.bake_smoothing / 30.0
                    limit_mod.min_y = -1.5
                    limit_mod.max_y = 1.5
                    
                elif props.bake_preset == 'SNARE':
                    env_mod.reference_value = 0.0
                    env_mod.influence = props.bake_smoothing / 25.0
                    limit_mod.min_y = -2.0
                    limit_mod.max_y = 2.0
                    
                elif props.bake_preset == 'HIHAT':
                    env_mod.reference_value = 0.0
                    env_mod.influence = props.bake_smoothing / 15.0
                    limit_mod.min_y = -3.0
                    limit_mod.max_y = 3.0
                    
                else:
                    env_mod.reference_value = 0.0
                    env_mod.influence = props.bake_smoothing / 20.0
                    limit_mod.min_y = -2.0
                    limit_mod.max_y = 2.0

            finally:
                # Restore original area type if we changed it
                if original_type:
                    temp_area.type = original_type

            self.report({'INFO'}, f"Audio baked to {props.bake_preset} geometry node successfully!")
            return {'FINISHED'}
            
        except Exception as e:
            self.report({'ERROR'}, f"Operation failed: {str(e)}")
            import traceback
            print(traceback.format_exc())
            return {'CANCELLED'}

class BEATANALYZER_OT_toggle_mute(Operator):
    bl_idname = "beatanalyzer.toggle_mute"
    bl_label = "Toggle Audio Mute"
    bl_description = "Toggle mute state of the analyzed audio"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.beat_analyzer_props
        scene = context.scene
        new_state = not props.audio_muted

        # Find and toggle audio
        found_audio = False
        for seq in scene.sequence_editor.sequences_all:
            if seq.type == 'SOUND' and seq.sound.filepath == props.audio_file:
                seq.mute = not seq.mute  # Toggle mute state
                props.audio_muted = seq.mute  # Update property to match
                found_audio = True
                break

        if set_audio_mute_state(context, new_state):
            return {'FINISHED'}
        else:
            self.report({'WARNING'}, "No audio found to toggle")
            return {'CANCELLED'}

class BEATANALYZER_OT_export(Operator):
    bl_idname = "beatanalyzer.export"
    bl_label = "Export Analysis"
    bl_description = "Export beat analysis data to JSON file"
    
    filepath: StringProperty(
        subtype='FILE_PATH',
        default="beat_analysis.json"
    )
    
    def execute(self, context):
        props = context.scene.beat_analyzer_props
        scene = context.scene
        
        export_data = {
            'file_info': {
                'audio_file': props.audio_file,
                'analysis_date': props.last_analysis_time,
                'duration': props.audio_duration,
                'total_beats': props.total_beats,
                'average_bpm': props.average_bpm
            },
            'analysis_settings': {
                'detection_method': props.detection_method,
                'frequency_bands': props.frequency_bands,
                'sensitivity': props.sensitivity,
                'noise_reduction': props.noise_reduction,
                'analysis_window': props.analysis_window
            },
            'beats': [
                {
                    'frame': marker.frame,
                    'time': marker.frame / scene.render.fps,
                    'name': marker.name,
                    'strength': marker.name.split('_')[-1]
                }
                for marker in scene.timeline_markers
            ]
        }
        
        try:
            with open(self.filepath, 'w', encoding='utf-8') as f:
                json.dump(export_data, f, indent=2)
            self.report({'INFO'}, f"Analysis exported to {self.filepath}")
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"Export failed: {str(e)}")
            return {'CANCELLED'}
    
    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

class BEATANALYZER_OT_next_marker(Operator):
    bl_idname = "beatanalyzer.next_marker"
    bl_label = "Next Beat Marker"
    bl_description = "Go to next beat marker"
    
    def execute(self, context):
        bpy.ops.screen.marker_jump(next=True)
        return {'FINISHED'}

class BEATANALYZER_OT_prev_marker(Operator):
    bl_idname = "beatanalyzer.prev_marker"
    bl_label = "Previous Beat Marker"
    bl_description = "Go to previous beat marker"
    
    def execute(self, context):
        bpy.ops.screen.marker_jump(next=False)
        return {'FINISHED'}

class BEATANALYZER_OT_bind_camera(Operator):
    bl_idname = "beatanalyzer.bind_camera"
    bl_label = "Bind Camera to Marker"
    bl_description = "Bind selected camera to current marker"
    
    @classmethod
    def poll(cls, context):
        return context.active_object and context.active_object.type == 'CAMERA'
    
    def execute(self, context):
        scene = context.scene
        current_frame = scene.frame_current
        
        # Find marker at current frame
        current_marker = None
        for marker in scene.timeline_markers:
            if marker.frame == current_frame:
                current_marker = marker
                break
        
        if not current_marker:
            self.report({'ERROR'}, "No marker at current frame")
            return {'CANCELLED'}
        
        # Bind camera using native Blender property
        current_marker.camera = context.active_object
        
        # Set scene camera to active camera
        scene.camera = context.active_object
        
        self.report({'INFO'}, f"Camera bound to marker {current_marker.name}")
        return {'FINISHED'}

class BEATANALYZER_OT_update_marker_visibility(Operator):
    bl_idname = "beatanalyzer.update_marker_visibility"
    bl_label = "Update Marker Visibility"
    bl_description = "Update the visibility of beat markers"
    
    def execute(self, context):
        scene = context.scene
        props = scene.beat_analyzer_props
        
        # Store markers data
        markers_data = []
        for marker in scene.timeline_markers:
            if marker.name.startswith(props.marker_prefix):
                strength = marker.name.split('_')[-1]
                if ((strength == 'strong' and props.show_strong_beats) or
                    (strength == 'medium' and props.show_medium_beats) or
                    (strength == 'weak' and props.show_weak_beats)):
                    markers_data.append((marker.name, marker.frame))
        
        # Clear markers using direct method
        while scene.timeline_markers:
            scene.timeline_markers.remove(scene.timeline_markers[0])
        
        # Restore visible markers
        for name, frame in markers_data:
            scene.timeline_markers.new(name, frame=frame)
        
        return {'FINISHED'}

class BEATANALYZER_OT_clear_markers(Operator):
    bl_idname = "beatanalyzer.clear_markers"
    bl_label = "Clear Beat Markers"
    bl_description = "Remove all beat markers"
    
    def execute(self, context):
        scene = context.scene
        
        # Clear markers 
        while scene.timeline_markers:
            scene.timeline_markers.remove(scene.timeline_markers[0])
            
        return {'FINISHED'}

class BEATANALYZER_PT_main_panel(Panel):
    bl_label = "Beat Analyzer Pro"
    bl_idname = "BEATANALYZER_PT_main_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Beat Analyzer'

    def draw(self, context):
        layout = self.layout
        props = context.scene.beat_analyzer_props

        # Audio File Selection 
        box = layout.box()
        row = box.row(align=True)
        split = row.split(factor=0.85, align=True)
        split.prop(props, "audio_file", text="")
        row = split.row(align=True)
        row.operator("beatanalyzer.browse_audio", text="", icon='FILE_FOLDER')
        row.operator("beatanalyzer.toggle_mute", text="", icon='SPEAKER' if not props.audio_muted else 'MUTE_IPO_OFF')

        # Main Analysis Button
        row = layout.row(align=True)
        row.scale_y = 1.5
        row.operator("beatanalyzer.analyze", text="Analyze Audio", icon='PLAY')

class BEATANALYZER_PT_analysis_settings(Panel):
    bl_label = "Analysis Settings"
    bl_parent_id = "BEATANALYZER_PT_main_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        props = context.scene.beat_analyzer_props

        # Method and Bands Settings
        box = layout.box()
        col = box.column(align=True)
        col.label(text="Detection Settings:", icon='SETTINGS')
        col.prop(props, "detection_method", text="Method")
        col.prop(props, "frequency_bands", text="Bands")
        
        if props.frequency_bands == 'CUSTOM':
            row = col.row(align=True)
            split = row.split(factor=0.5, align=True)
            split.prop(props, "custom_freq_low", text="Low Hz")
            split.prop(props, "custom_freq_high", text="High Hz")
        
        # Sensitivity Settings
        box = layout.box()
        col = box.column(align=True)
        col.label(text="Sensitivity Controls:", icon='FORCE_FORCE')
        col.prop(props, "sensitivity", slider=True)
        col.prop(props, "noise_reduction", slider=True)
        
        # BPM Range
        box = layout.box()
        col = box.column(align=True)
        col.label(text="BPM Range:", icon='TEMP')
        row = col.row(align=True)
        row.prop(props, "min_bpm", text="Min")
        row.prop(props, "max_bpm", text="Max")

class BEATANALYZER_PT_beat_settings(Panel):
    bl_label = "Beat Settings"
    bl_parent_id = "BEATANALYZER_PT_main_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        props = context.scene.beat_analyzer_props

        # Beat Refinement
        box = layout.box()
        col = box.column(align=True)
        col.label(text="Beat Refinement:", icon='MODIFIER')
        col.prop(props, "beat_refinement", text="")
        
        # Strength Thresholds
        box = layout.box()
        col = box.column(align=True)
        col.label(text="Beat Strength Thresholds:", icon='FORCE_TURBULENCE')
        col.prop(props, "strong_beat_threshold", slider=True)
        col.prop(props, "medium_beat_threshold", slider=True)

        # Marker Settings
        box = layout.box()
        col = box.column(align=True)
        col.label(text="Marker Settings:", icon='MARKER')
        col.prop(props, "marker_prefix")
        row = col.row(align=True)
        row.prop(props, "show_strong_beats", toggle=True, icon='RADIOBUT_ON')
        row.prop(props, "show_medium_beats", toggle=True, icon='RADIOBUT_ON')
        row.prop(props, "show_weak_beats", toggle=True, icon='RADIOBUT_ON')

class BEATANALYZER_PT_baking_settings(Panel):
    bl_label = "Audio Baking"
    bl_parent_id = "BEATANALYZER_PT_main_panel" 
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        props = context.scene.beat_analyzer_props

        # Main baking controls
        box = layout.box()
        col = box.column(align=True)
        col.label(text="Bake Settings:", icon='MODIFIER_DATA')
        
        # Preset selector with larger scale
        row = col.row(align=True)
        row.scale_y = 1.2
        row.prop(props, "bake_preset", text="")

        # Frequency band focus for presets
        if props.bake_preset != 'CUSTOM':
            col.prop(props, "freq_band_focus", text="Focus")
            col.separator()
        
        # Bake action buttons
        row = layout.row(align=True)
        row.scale_y = 1.5
        split = row.split(factor=0.5, align=True)
        split.operator("beatanalyzer.bake_to_shader", text="Bake to Shader", icon='NODE_MATERIAL')
        split.operator("beatanalyzer.bake_to_geometry", text="Bake to Geometry", icon='NODETREE')

        # Custom settings
        if props.bake_preset == 'CUSTOM':
            self.draw_custom_settings(layout, props)
        else:
            self.draw_preset_info(layout, props)

    def draw_custom_settings(self, layout, props):
        # Frequency range settings
        box = layout.box()
        col = box.column(align=True)
        col.label(text="Frequency Range:", icon='GRAPH')
        row = col.row(align=True)
        row.prop(props, "low_freq", text="Low")
        row.prop(props, "high_freq", text="High")
        
        # Time settings  
        col.separator(factor=0.5)
        row = col.row(align=True)
        row.prop(props, "attack_time", text="Attack")
        row.prop(props, "release_time", text="Release")
        
        # Threshold settings
        box = layout.box() 
        col = box.column(align=True)
        col.label(text="Threshold Settings:", icon='NORMALIZE_FCURVES')
        col.prop(props, "threshold", text="Primary", slider=True)
        col.prop(props, "sthreshold", text="Secondary", slider=True)
        col.prop(props, "bake_smoothing", text="Smoothing", slider=True)
        
        # Processing options
        box = layout.box()
        col = box.column(align=True)
        col.label(text="Processing Options:", icon='MODIFIER_DATA')
        
        grid = col.grid_flow(row_major=True, columns=3, align=True)
        grid.prop(props, "use_accumulate", text="Accumulate", toggle=True, icon='NORMALIZE_FCURVES')
        grid.prop(props, "use_additive", text="Additive", toggle=True, icon='PLUS')
        grid.prop(props, "use_square", text="Square", toggle=True, icon='MESH_PLANE')

    def draw_preset_info(self, layout, props):
        # Preset frequency information
        box = layout.box()
        col = box.column(align=True)
        col.label(text="Preset Frequency Ranges:", icon='GRAPH')
        
        preset_ranges = {
            'KICK': [
                ("Thump", "60-100Hz"),
                ("Round", "100-250Hz"), 
                ("Box", "400-600Hz"),
                ("Attack", "2-6kHz"),
                ("Click", "4-8kHz")
            ],
            'SNARE': [
                ("Warmth", "100-150Hz"),
                ("Fat", "150-250Hz"),
                ("Box", "800-1000Hz"), 
                ("Attack", "2.5-5kHz"),
                ("Crisp", "8-10kHz")
            ],
            'HIHAT': [
                ("Body", "200-800Hz"),
                ("Presence", "2-4kHz"),
                ("Sizzle", "6-12kHz"),
                ("Air", "12-16kHz"),
                ("Sparkle", "16-20kHz")
            ],
            'BASS': [
                ("Sub", "20-60Hz"),
                ("Bottom", "60-120Hz"),
                ("Punch", "120-250Hz"),
                ("Growl", "250-500Hz"),
                ("Edge", "500-1000Hz")
            ],
            'VOCAL': [
                ("Rumble", "20-60Hz"),
                ("Warmth", "120-250Hz"),
                ("Presence", "2-4kHz"),
                ("Clarity", "4-8kHz"),
                ("Air", "8-16kHz")
            ],
            'SYNTH': [
                ("Sub", "20-80Hz"),
                ("Body", "80-240Hz"),
                ("Mid", "240-2000Hz"),
                ("Buzz", "2-8kHz"),
                ("Brilliance", "8-20kHz")
            ]
        }
        
        if props.bake_preset in preset_ranges:
            grid = col.grid_flow(row_major=True, columns=2, align=True)
            for name, range in preset_ranges[props.bake_preset]:
                grid.label(text=f"{name}:")
                grid.label(text=range)

class BEATANALYZER_PT_marker_tools(Panel):
    bl_label = "Marker Tools"
    bl_parent_id = "BEATANALYZER_PT_main_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        
        # Navigation Tools
        box = layout.box()
        col = box.column(align=True)
        col.label(text="Marker Navigation:", icon='MARKER')
        row = col.row(align=True)
        row.operator("beatanalyzer.prev_marker", text="", icon='PREV_KEYFRAME')
        row.operator("beatanalyzer.next_marker", text="", icon='NEXT_KEYFRAME')
        row.operator("beatanalyzer.bind_camera", text="Bind Camera", icon='CAMERA_DATA')
        
        # Marker Management
        box = layout.box()
        col = box.column(align=True)
        col.label(text="Marker Management:", icon='GHOST_ENABLED')
        row = col.row(align=True)
        row.operator("beatanalyzer.update_marker_visibility", text="Update Visibility", icon='HIDE_OFF')
        row.operator("beatanalyzer.clear_markers", text="Clear All", icon='X')

class BEATANALYZER_PT_utilities(Panel):
    bl_label = "Utilities"
    bl_parent_id = "BEATANALYZER_PT_main_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        props = context.scene.beat_analyzer_props

        # Export Tools
        box = layout.box()
        col = box.column(align=True)
        col.label(text="Export Tools:", icon='EXPORT')
        col.operator("beatanalyzer.export", text="Export Analysis", icon='FILE_BLANK')
        
        # Cache Settings
        box = layout.box()
        col = box.column(align=True)
        col.label(text="Cache Settings:", icon='FILE_CACHE')
        row = col.row(align=True)
        row.prop(props, "use_cache", text="Use Cache", toggle=True)
        row.prop(props, "debug_mode", text="Debug", toggle=True)

class BEATANALYZER_PT_analysis_results(Panel):
    bl_label = "Analysis Results"
    bl_parent_id = "BEATANALYZER_PT_main_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        props = context.scene.beat_analyzer_props

        if props.total_beats > 0:
            # Analysis Stats
            box = layout.box()
            col = box.column(align=True)
            col.label(text="Analysis Statistics:", icon='INFO')
            
            row = col.row(align=True)
            split = row.split(factor=0.5)
            split.label(text="Total Beats:")
            split.label(text=str(props.total_beats))
            
            row = col.row(align=True)
            split = row.split(factor=0.5)
            split.label(text="Average BPM:")
            split.label(text=f"{props.average_bpm:.1f}")
            
            row = col.row(align=True)
            split = row.split(factor=0.5)
            split.label(text="Duration:")
            split.label(text=f"{props.audio_duration:.2f}s")
            
            col.separator()
            col.label(text=f"Last Analysis: {props.last_analysis_time}")
            
            # Debug Information
            if props.debug_mode:
                box = layout.box()
                col = box.column(align=True)
                col.label(text="Debug Information:", icon='CONSOLE')
                col.label(text=props.debug_info)
        else:
            layout.label(text="No analysis performed yet", icon='INFO')



# Registration
classes = (
    BeatAnalyzerProperties,
    BEATANALYZER_OT_analyze,
    BEATANALYZER_OT_bake_to_shader,
    BEATANALYZER_OT_bake_to_geometry,
    BEATANALYZER_OT_browse_audio,
    BEATANALYZER_OT_export,
    BEATANALYZER_OT_next_marker,
    BEATANALYZER_OT_prev_marker,
    BEATANALYZER_OT_bind_camera,
    BEATANALYZER_OT_update_marker_visibility,
    BEATANALYZER_OT_clear_markers,
    BEATANALYZER_OT_toggle_mute,
    BEATANALYZER_PT_main_panel,
    BEATANALYZER_PT_analysis_settings,
    BEATANALYZER_PT_beat_settings,
    BEATANALYZER_PT_baking_settings,
    BEATANALYZER_PT_marker_tools,
    BEATANALYZER_PT_utilities,
    BEATANALYZER_PT_analysis_results
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.beat_analyzer_props = bpy.props.PointerProperty(type=BeatAnalyzerProperties)

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.beat_analyzer_props

if __name__ == "__main__":
    register()
